package a3_1801040089;

import utils.DOpt;
import utils.OptType;
import utils.TextIO;

/**
 * @overview 
 *   generate and return a tabular report about PC objects in this.
 */
public class PCReport {

    /**
     * @effects
     *  generate and return a tabular report about PC objects in this.
     *
     *  <p>The report title is displayed in the middle of the first line.
     *  All but the first column correspond to the PC attributes,
     *  the rows are data about the PC objects. The first column sequentially
     *  displays the row numbers.
     *
     *  <p>The column widths are calculated based on the attribute lengths
     *  such that the cell values are properly aligned with the columns and are displayed
     *  right-justified. Further, cells on same row are at least one space apart
     *  from each other.
     *
     *  <p>e.g.<br>
     *  --------------------------------------------------------------------------------
     *                                 PCPROG REPORT
     *  --------------------------------------------------------------------------------
     *  1  Vostro 3650MT      2016    DELL      [Intel-Core-i3-6100 CPU,4GB-DDR3L RAM, ...]
     *  2  ...
     *  3  ...
     *  --------------------------------------------------------------------------------
     */
    public String displayReport(PC[] objects) {
        int col1 = 3, col2 = PC.LENGTH_MODEL, col3 = 6,
                col4 = PC.LENGTH_MANUFACTURER, col5 = 50;
        String str = "";
        int count = 1;
        str += "---------------------------------------------------------------------------------------------------\n";
        str += "                                           PCPROG REPORT\n";
        str += "---------------------------------------------------------------------------------------------------\n";
        for (PC pc : objects) {
            str += String.format("%" + col1 + "s", count + " ");
            str += String.format("%" + col2 + "s", pc.getModel() + " ");
            str += String.format("%" + col3 + "s", pc.getYear() + " ");
            str += String.format("%" + col4 + "s", pc.getManufacturer() + " ");
            str += String.format("%" + col5 + "s%n", pc.getComps().toString());
            count++;
        }
        str += "---------------------------------------------------------------------------------------------------\n";
        return str;
    }

}