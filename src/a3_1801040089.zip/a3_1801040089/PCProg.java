package a3_1801040089;

import utils.DomainConstraint;
import utils.TextIO;

import static utils.TextIO.*;

/**
 * @overview PCProg is a program that captures data about PC objects
 *    and displays a report about them on the console.
 * 
 * @attributes
 *  objs  Set
 *  
 * @object
 *  A typical PCProg is {c1,...,cn} where c1,...,cn are pcs
 * 
 * @abstract_properties
 *  mutable(objs)=true /\ optional(objs)=false
 * 
 * @author dmle
 */
public class PCProg {
  @DomainConstraint(type="Set",mutable=true,optional=false)
  private Set objs;
  
  /**
   * @effects
   *  initialise this to have an empty set of PCs
   */
  public PCProg() {
    objs = new Set();
  }

  /**
   * @effects
   *	create PC objects
   */
  public void createObjects() {
    boolean isContinue = true;
    do {
      putln("Enter your PC model: ");
      String PC_Model = getln();
      putln("Enter your PC year: ");
      int PC_Year = getlnInt();
      putln("Enter your PC manufacturer: ");
      String PC_Manufacturer = getln();
      Set set = new Set();
      putln("Enter your set of components: ");
      String PC_Comps = getln();
      set.add (PC_Comps);
      PC pc = new PC(PC_Model, PC_Year, PC_Manufacturer, set);
      if (pc.repOk()) {
        boolean isIn = false;
        for (int i = 0; i < objs.size(); i++) {
          if (pc.equals(objs.getElement(i))) {
            putln ("This PC has already been created!");
            isIn = true;
          }
        }
        if (!isIn) {
          objs.add (pc);
          putln ("Your PC is successfully created");
        }
      }
      putln ("Do you want to continue ?(Y/N) ");
      Iteration:
      while (true) {
        char yourChoice = getlnChar();
        if (yourChoice == 'Y') break Iteration;
        else if (yourChoice == 'N') {
          isContinue = false;
          break Iteration;
        } else {
          System.err.println("Invalid input! Please try again: ");
          break;
        }
      }
  } while (isContinue);

  }
  
  /**
   * @effects
   *  if this has objects
   *    display a text-based tabular report and return this report
   *  else
   *    display nothing and return null
   */
  public String displayReport() {
    if (objs.size() > 0) {
      Object[] objsArr = objs.getObjects();
      PC[] pcs = new PC[objsArr.length];
      int i = 0;
      for (Object o : objsArr) {
        pcs[i++] = (PC) o;
      }
      
      PCReport reportObj = new PCReport();
      return reportObj.displayReport(pcs);
    } else {
      return null;
    }
  }
  
  /**
   * @effects 
   *  save report to a file pcs.txt in the same directory 
   *  as the program's
   */
  public void saveReport(String report) {
    String fileName = "pcs.txt";
    writeFile(fileName);
    putln(report);
    writeStandardOutput();
  }

  /**
   * The run method
   * @effects
   *  initialise an instance of PCProg 
   *  create objects from data entered by the user
   *  display a report on the objects 
   *  prompt user to save report to file
   *  if user answers "Y"
   *    save report 
   *  else
   *    end 
   */
  public static void main(String[] args) {
    //
    PCProg prog = new PCProg();
    
    // create objects
    prog.createObjects();
  
    // display report
    String report = prog.displayReport();
      
    if (report != null) {
      // prompt user to save report
      putln("Save report to file? [Y/N]");
      String toSave = getln();
      if (toSave.equals("Y")) {
        prog.saveReport(report);
        putln("report saved");
      }
    }
    
    putln("~END~");
  }
}
