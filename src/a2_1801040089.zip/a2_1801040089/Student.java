package a2_1801040089;

import utils.AttrRef;
import utils.DOpt;
import utils.DomainConstraint;
import utils.OptType;

/**
 * @overview represents the information of university students
 * @attributes
 *      id              Integer         int
 *      firstName       String
 *      givenName       String
 *      lastName        String
 *      email           String
 *      address         String
 *      phone           String
 *      dob             String
 *      gender          Gender
 * @object a typical Student object is c=<i,f,g,l,e,a,p,d,g>,
 * where id(i), firstName(f), givenName(g), lastName(l), emmail(l),
 * address(a), phone(p), dob(d), gender(g)
 * @abstract_properties
 * mutable(id) = false /\ optional(id) = false /\ min(id) = 1 /\
 * mutable(firstName) = true /\ optional(firstName) = false /\ length(firstName) = 50 /\
 * mutable(givenName) = true /\ optional(givenName) = false /\ length(givenName) = 50 /\
 * mutable(lastName) = true /\ optional(lastName) = false /\ length(lastName) = 30 /\
 * mutable(email) = true /\ optional(email) = true /\ length(email) = 255 /\
 * mutable(address) = true /\ optional(address) = false /\ length(address) = 2000 /\
 * mutable(phone) = true /\ optional(phone) = false /\ length(phone) = 20 /\
 * mutable(dob) = false /\ optional(dob) = false /\ length(dob) = 20 /\
 * mutable(gender) = false /\ optional(gender) = false
 */

public class Student {
    @DomainConstraint(type="Integer", mutable = false, optional = false, min = 1)
    private int id;
    @DomainConstraint(type = "String", mutable = true, optional = false, length = 50)
    private String firstName;
    @DomainConstraint(type = "String", mutable = true, optional = false, length = 50)
    private String givenName;
    @DomainConstraint(type = "String", mutable = true, optional = false, length = 30)
    private String lastName;
    @DomainConstraint(type = "String", mutable = true, optional = true, length = 255)
    private String email;
    @DomainConstraint(type = "String", mutable = true, optional = false, length = 2000)
    private String address;
    @DomainConstraint(type = "String", mutable = true, optional = false, length = 20)
    private String phone;
    @DomainConstraint(type = "String", mutable = false, optional = false, length = 20)
    private String dob;
    @DomainConstraint(type = "Gender", mutable = false, optional = false)
    private Gender gender;

    // Constants
    private static final int MIN_ID = 1;
    private static final int LENGTH_FIRSTNAME = 50;
    private static final int LENGTH_GIVENNAME = 50;
    private static final int LENGTH_LASTNAME = 30;
    private static final int LENGTH_EMAIL = 255;
    private static final int LENGTH_ADDRESS = 2000;
    private static final int LENGTH_PHONE = 20;
    private static final int LENGTH_DOB = 20;

    // Constructor Methods

    /**
     * effects <pre>
     *     if studentID, firstName, givenName, lastName, address, phone, dob and gender are valid
     *          initialize this as <studentID,firstName,givenName,lastName,address,phone,dob,gender>
     *     else
     *          initialize this as <> and display errors
     * </pre>
     */
    public Student(@AttrRef ("id") int studentID, @AttrRef ("firstName") String firstName,
                   @AttrRef ("givenName") String givenName, @AttrRef ("lastName") String lastName,
                   @AttrRef ("address") String address, @AttrRef ("phone") String phone ,
                   @AttrRef ("dob") String dob, @AttrRef ("gender") Gender gender) {
        if (!validateId (studentID)) {
            System.err.println ("Invalid student id: " + studentID);
            return;
        }

        if (!validateFirstName (firstName)) {
            System.err.println ("Invalid first name student: " + firstName);
            return;
        }

        if (!validateGivenName (givenName)) {
            System.err.println ("Invalid given name student: " + givenName);
            return;
        }

        if (!validateLastName (lastName)) {
            System.err.println ("Invalid last name student: " + lastName);
            return;
        }

        if (!validateAddress (address)) {
            System.err.println ("Invalid address student: " + address);
            return;
        }

        if (!validatePhone (phone)) {
            System.err.println ("Invalid phone student: " + phone);
            return;
        }

        if (!validateDob (dob)) {
            System.err.println ("Invalid student date of birth(dob): " + dob);
            return;
        }

        if (!validateGender (gender)) {
            System.err.println ("Invalid student gender: " + gender);
            return;
        }

        id = studentID;
        this.firstName = firstName;
        this.givenName = givenName;
        this.lastName = lastName;
        this.address = address;
        this.phone = phone;
        this.dob = dob;
        this.gender = gender;
    }

    /**
     * @effects return this.id
     */
     @DOpt (type= OptType.Observer) @AttrRef ("id")
     public int getId() { return this.id; }

    /**
     * @effects return this.firstName
     */
    @DOpt (type= OptType.Observer) @AttrRef ("firstName")
    public String getFirstName() { return this.firstName; }

    /**
     * @effects return this.givenName
     */
    @DOpt (type= OptType.Observer) @AttrRef ("givenName")
    public String getGivenName() { return this.givenName; }

    /**
     * @effects return this.lastName
     */
    @DOpt (type= OptType.Observer) @AttrRef ("lastName")
    public String getLastName() { return this.lastName; }

    /**
     * @effects return this.email
     */
    @DOpt (type= OptType.Observer) @AttrRef ("email")
    public String getEmail() { return this.email; }

    /**
     * @effects return this.address
     */
    @DOpt (type= OptType.Observer) @AttrRef ("address")
    public String getAddress() { return this.address; }

    /**
     * @effects return this.phone
     */
    @DOpt (type= OptType.Observer) @AttrRef ("phone")
    public String getPhone() { return this.phone; }

    /**
     * @effects return this.dob
     */
    @DOpt (type= OptType.Observer) @AttrRef ("dob")
    public String getDob() { return this.dob; }

    /**
     * @effects return this.gender
     */
    @DOpt (type= OptType.Observer) @AttrRef ("gender")
    public Gender getGender() { return this.gender; }


    /**
     * @effects <pre>
     *     if firstName is valid
     *          set this.firstName = firstName
     *          return true
     *     else
     *          return false
     * </pre>
     */
    @DOpt (type=OptType.Mutator) @AttrRef("firstName")
    public boolean setFirstName(String firstName) {
        if (validateFirstName (firstName)) {
            this.firstName = firstName;
            return true;
        } else {
            return false;
        }
    }

    /**
     * @effects <pre>
     *     if givenName is valid
     *          set this.givenName = givenName
     *          return true
     *     else
     *          return false
     * </pre>
     */
    @DOpt (type=OptType.Mutator) @AttrRef("givenName")
    public boolean setGivenName(String givenName) {
        if (validateGivenName (givenName)) {
            this.givenName = givenName;
            return true;
        } else {
            return false;
        }
    }

    /**
     * @effects <pre>
     *     if lastName is valid
     *          set this.lastName = lastName
     *          return true
     *     else
     *          return false
     * </pre>
     */
    @DOpt (type=OptType.Mutator) @AttrRef("lastName")
    public boolean setLastName(String lastName) {
        if (validateLastName (lastName)) {
            this.lastName = lastName;
            return true;
        } else {
            return false;
        }
    }

    /**
     * @effects <pre>
     *     if email is valid
     *          set this.email = email
     *          return true
     *     else
     *          return false
     * </pre>
     */
    @DOpt (type=OptType.Mutator) @AttrRef("email")
    public boolean setEmail(String email) {
        if (validateEmail (email)) {
            this.email = email;
            return true;
        } else {
            return false;
        }
    }

    /**
     * @effects <pre>
     *     if address is valid
     *          set this.address = address
     *          return true
     *     else
     *          return false
     * </pre>
     */
    @DOpt (type=OptType.Mutator) @AttrRef("address")
    public boolean setAddress(String address) {
        if (validateAddress (address)) {
            this.address = address;
            return true;
        } else {
            return false;
        }
    }

    /**
     * @effects <pre>
     *     if phone is valid
     *          set this.phone = phone
     *          return true
     *     else
     *          return false
     * </pre>
     */
    @DOpt (type=OptType.Mutator) @AttrRef("phone")
    public boolean setPhone(String phone) {
        if (validatePhone (phone)) {
            this.phone = phone;
            return true;
        } else {
            return false;
        }
    }

    /**
     * @effects <pre>
     *  if id is valid
     *    return true
     *  else
     *    return false
     *  </pre>
     */
    private boolean validateId(int id) {
        return id >= MIN_ID;
    }

    /**
     * @effects <pre>
     *  if firstName is valid
     *    return true
     *  else
     *    return false
     *  </pre>
     */
    private boolean validateFirstName(String firstName) {
        return (firstName != null && firstName.length () > 0 && firstName.length () <= LENGTH_FIRSTNAME);
    }

    /**
     * @effects <pre>
     *  if givenName is valid
     *    return true
     *  else
     *    return false
     *  </pre>
     */
    private boolean validateGivenName(String givenName) {
        return (givenName != null && givenName.length () > 0 && givenName.length () <= LENGTH_GIVENNAME);
    }

    /**
     * @effects <pre>
     *  if lastName is valid
     *    return true
     *  else
     *    return false
     *  </pre>
     */
    private boolean validateLastName(String lastName) {
        return (lastName != null && lastName.length () > 0 && lastName.length () <= LENGTH_LASTNAME);
    }

    /**
     * @effects <pre>
     *  if email is valid
     *    return true
     *  else
     *    return false
     *  </pre>
     */
    private boolean validateEmail(String email) {
        return (email != null && email.length () > 0 && email.length () <= LENGTH_EMAIL);
    }

    /**
     * @effects <pre>
     *  if address is valid
     *    return true
     *  else
     *    return false
     *  </pre>
     */
    private boolean validateAddress(String address) {
        return (address != null && address.length () > 0 && address.length () <= LENGTH_ADDRESS);
    }

    /**
     * @effects <pre>
     *  if phone is valid
     *    return true
     *  else
     *    return false
     *  </pre>
     */
    private boolean validatePhone(String phone) {
        return (phone != null && phone.length () > 0 && phone.length () <= LENGTH_PHONE);
    }

    /**
     * @effects <pre>
     *  if dob is valid
     *    return true
     *  else
     *    return false
     *  </pre>
     */
    private boolean validateDob(String dob) {
        return (dob != null && dob.length () > 0 && dob.length () <= LENGTH_DOB);
    }

    /**
     * @effects <pre>
     *   if gender is valid
     *      return true
     *   else
     *      return false
     *  </pre>
     */
    private boolean validateGender(Gender gender) {
        return (gender != null);
    }

    @Override
    public String toString() {
        return ("Student:<" + id + ", " + firstName + ", " + givenName + ", "
                + lastName + ", " + email + ", " + address
                + ", " + phone + ", " + dob + ", " + gender  + ">");
    }

    @Override
    public boolean equals(Object o) {
        if (!(o instanceof Student))
            return false;

        int yourID = ((Student) o).id;
        return yourID == id;

    }

    /**
     * @effects <pre>
     *   if this satisfies abstract properties
     *     return true
     *   else
     *     return false</pre>
     */
    public boolean repOK() {
        return validateId(id) && validateFirstName (firstName) &&
               validateGivenName (givenName) && validateEmail (email) &&
               validateAddress (address) && validatePhone (phone) &&
               validateDob (dob) && validateGender (gender);
    }
}


















