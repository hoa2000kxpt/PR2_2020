package a2_1801040089;

public enum Gender {
    Male, Female
}
